# SIGE360 MVP

Aplicativo web inicial para gestión de edificios, personas, RRHH, tickets y mantenimiento.

## Cómo ejecutarlo

Necesitas tener Node.js instalado.

```bash
cd sige360
npm start
```

Luego abre:

```text
http://localhost:3000
```

## Login demo

Puedes entrar con cualquier correo y contraseña.

Ejemplo:

- Correo: admin@sige360.local
- Contraseña: admin123

## Módulos incluidos

- Dashboard
- Edificios
- Personas
- RRHH / empleados
- Tickets
- Mantenimiento

## Base de datos actual

La información se guarda en:

```text
data/db.json
```

## Siguiente versión recomendada

- PostgreSQL
- Autenticación real
- Roles y permisos
- Gestión documental
- Multiempresa / multiedificio
- Reportes avanzados
