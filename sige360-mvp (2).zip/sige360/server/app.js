const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, '..');
const PUBLIC_DIR = path.join(ROOT, 'public');
const DB_PATH = path.join(ROOT, 'data', 'db.json');

const seed = {
  edificios: [
    { id: 1, nombre: 'Edificio Central', direccion: 'Av. Principal 123', ciudad: 'Santiago', estado: 'Activo' },
    { id: 2, nombre: 'Torre Norte', direccion: 'Calle Norte 456', ciudad: 'Valparaíso', estado: 'Activo' }
  ],
  personas: [
    { id: 1, nombre: 'Ana Pérez', documento: '11.111.111-1', correo: 'ana@example.com', telefono: '+56 9 1111 1111', tipo: 'Propietario' },
    { id: 2, nombre: 'Carlos Rojas', documento: '22.222.222-2', correo: 'carlos@example.com', telefono: '+56 9 2222 2222', tipo: 'Empleado' }
  ],
  empleados: [
    { id: 1, nombre: 'Carlos Rojas', cargo: 'Conserje', edificio: 'Edificio Central', turno: 'Mañana', estado: 'Activo' }
  ],
  tickets: [
    { id: 1, titulo: 'Fuga en piso 3', edificio: 'Edificio Central', prioridad: 'Alta', estado: 'Abierto', responsable: 'Carlos Rojas' }
  ],
  mantenimientos: [
    { id: 1, equipo: 'Ascensor A', edificio: 'Edificio Central', tipo: 'Preventivo', fecha: '2026-06-10', estado: 'Programado' }
  ]
};

function ensureDb() {
  if (!fs.existsSync(path.dirname(DB_PATH))) fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, JSON.stringify(seed, null, 2));
}

function readDb() {
  ensureDb();
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function writeDb(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function sendJson(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => body += chunk.toString());
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); } catch { resolve({}); }
    });
  });
}

function serveStatic(req, res) {
  const requested = req.url === '/' ? '/index.html' : new URL(req.url, `http://localhost:${PORT}`).pathname;
  const filePath = path.normalize(path.join(PUBLIC_DIR, requested));
  if (!filePath.startsWith(PUBLIC_DIR)) return sendJson(res, 403, { error: 'Acceso denegado' });
  fs.readFile(filePath, (err, content) => {
    if (err) return sendJson(res, 404, { error: 'No encontrado' });
    const ext = path.extname(filePath).toLowerCase();
    const type = ext === '.html' ? 'text/html' : ext === '.css' ? 'text/css' : ext === '.js' ? 'text/javascript' : 'text/plain';
    res.writeHead(200, { 'Content-Type': `${type}; charset=utf-8` });
    res.end(content);
  });
}

const allowed = ['edificios', 'personas', 'empleados', 'tickets', 'mantenimientos'];

async function router(req, res) {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const parts = url.pathname.split('/').filter(Boolean);

  if (parts[0] === 'api') {
    const db = readDb();
    if (url.pathname === '/api/resumen') {
      return sendJson(res, 200, {
        edificios: db.edificios.length,
        personas: db.personas.length,
        empleados: db.empleados.length,
        ticketsAbiertos: db.tickets.filter(t => t.estado !== 'Cerrado').length,
        mantenimientosPendientes: db.mantenimientos.filter(m => m.estado !== 'Completado').length
      });
    }
    if (url.pathname === '/api/login' && req.method === 'POST') {
      const body = await parseBody(req);
      if (body.email && body.password) return sendJson(res, 200, { token: 'demo-token', usuario: { nombre: 'Administrador', rol: 'Super Admin' } });
      return sendJson(res, 400, { error: 'Email y contraseña requeridos' });
    }
    const resource = parts[1];
    if (!allowed.includes(resource)) return sendJson(res, 404, { error: 'Recurso no encontrado' });
    if (req.method === 'GET') return sendJson(res, 200, db[resource]);
    if (req.method === 'POST') {
      const body = await parseBody(req);
      const nextId = db[resource].length ? Math.max(...db[resource].map(x => Number(x.id) || 0)) + 1 : 1;
      const item = { id: nextId, ...body };
      db[resource].push(item);
      writeDb(db);
      return sendJson(res, 201, item);
    }
    if (req.method === 'DELETE') {
      const id = Number(parts[2]);
      db[resource] = db[resource].filter(item => item.id !== id);
      writeDb(db);
      return sendJson(res, 200, { ok: true });
    }
    return sendJson(res, 405, { error: 'Método no permitido' });
  }

  serveStatic(req, res);
}

http.createServer(router).listen(PORT, () => {
  console.log(`SIGE360 MVP funcionando en http://localhost:${PORT}`);
});
